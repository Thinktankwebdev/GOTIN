$(document).ready(function() { 
	$('.accordion').each(function () {
		var $accordian = $(this);
		$accordian.find('.accordion-head').on('click', function () {
			$accordian.find('.accordion-head').removeClass('open');
			$(this).removeClass('open').addClass('closeAcc');
			$accordian.find('.accordion-body').slideUp();
			if (!$(this).next().is(':visible')) {
				$(this).removeClass('closeAcc').addClass('open');
				$(this).next().slideDown();
			}
		});
	});
	
	
});

$('.deleteNotify').on('click', function(){
  $(this).parent().remove();
});

$(document).ready(function(){
    $(".notifyBtn").click(function(){
        $("#notifyPopup").toggle();
    });
});
